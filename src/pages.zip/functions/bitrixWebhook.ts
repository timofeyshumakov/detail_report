import { DEAL_DATE_FIELD, type DealDateFilter } from './dateFilter';

const SERVER_HANDLER_URL = 'https://master.rymar-consulting.ru/request/handler.php';

export type BitrixDealListItem = {
  ID: string;
  UF_CRM_1744096783472: string;
};

export type BitrixDealListResponse = {
  result: BitrixDealListItem[];
  total: number;
  next?: number;
};

export async function fetchDealsByDateFilter(
  dateFilter: DealDateFilter,
  options: { start?: number; limit?: number } = {},
): Promise<BitrixDealListResponse> {
  const params: Record<string, unknown> = {
    method: 'crm.deal.list',
    select: ['ID', DEAL_DATE_FIELD],
    order: { [DEAL_DATE_FIELD]: 'DESC' },
    start: options.start ?? 0,
    limit: options.limit ?? 50,
  };

  const filter: Record<string, unknown> = {};
  if (dateFilter[`>${DEAL_DATE_FIELD}`]) {
    filter[`>${DEAL_DATE_FIELD}`] = dateFilter[`>${DEAL_DATE_FIELD}`];
  }
  if (dateFilter[`<${DEAL_DATE_FIELD}`]) {
    filter[`<${DEAL_DATE_FIELD}`] = dateFilter[`<${DEAL_DATE_FIELD}`];
  }
  if (Object.keys(filter).length > 0) {
    params.filter = filter;
  }

  const response = await fetch(SERVER_HANDLER_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });

  if (!response.ok) {
    throw new Error(`Server handler error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();

  if (data.error) {
    throw new Error(data.error_description || data.error);
  }

  return {
    result: data.data || [],
    total: data.total ?? 0,
  };
}
