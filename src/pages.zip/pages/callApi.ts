export const SERVER_HANDLER_URL = 'https://master.rymar-consulting.ru/request/handler.php';

export function getServerHandlerUrl(override?: string): string {
    const url = override || SERVER_HANDLER_URL;
    return url.endsWith('/') ? url : `${url}/`;
}

export async function callApi(
    method: string,
    filter: {},
    select: string[] | null,
    entityTypeId: number | number[] | string[] | null,
_batchNumber: number = 0,               
    _parsed: number = 0,
): Promise<any[]> {
    // Преобразуем параметры в формат серверного handler
    const params: Record<string, unknown> = {
        method,
        filters: filter || {},
        select: select || null,
    };

    // entityTypeId для динамических полей
    if (entityTypeId != null) {
        params.entityTypeId = entityTypeId;
    }

    // Специальные параметры для разных методов
    if (method === 'lists.element.get') {
        // Для lists.element.get нужен IBLOCK_ID и IBLOCK_TYPE_ID
        if (entityTypeId != null) {
            params.IBLOCK_ID = entityTypeId;
        }
        params.IBLOCK_TYPE_ID = 'lists';
    }

    if (method === 'user.get') {
        // Для user.get используем filter вместо FILTER
        params.filter = filter || {};
    }

    try {
        const response = await fetch(getServerHandlerUrl(), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(params),
        });

        if (!response.ok) {
            throw new Error(`Server handler error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();

        if (data.error) {
            throw new Error(data.error);
        }

        return data.data || [];
    } catch (error) {
        console.error(`callApi error for ${method}:`, error);
        return [];
    }
}

// Получение элементов списка с поддержкой полной загрузки
export async function getListElements(
    iblockId: number = 0, 
    filter: object = {}, 
    select: string[] = ['ID', 'NAME']
): Promise<any[]> {
    return callApi('lists.element.get', filter, select, iblockId, 0, 0);
}

// Выполнение batch-запросов через серверный handler
export async function callBatchCommands(commands: Array<{ method: string; params?: Record<string, unknown> }>): Promise<any[]> {
    const results = await Promise.all(
        commands.map(async (cmd) => {
            try {
                return await callApi(cmd.method, cmd.params || {}, null, null, 0, 0);
            } catch (error) {
                console.error(`Batch command error for ${cmd.method}:`, error);
                return [];
            }
        })
    );
    return results;
}
